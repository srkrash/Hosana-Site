/* 
  Script para Processar Formulário de Contato
  - Valida Google reCAPTCHA
  - Salva na Planilha (incluindo Telefone)
  - Previne injeção de Fórmulas no Sheets (CSV Injection)
  - Envia notificação por Email
*/

// CONFIGURAÇÃO
const EMAIL_PARA_NOTIFICACAO = "hosana.goncalves.neuropsi@gmail.com";
const ASSUNTO_EMAIL = "Novo Contato pelo Site";
const RECAPTCHA_SECRET = "6Le7n3wsAAAAAO87pyLwNLoxBbA47OOVZuLBTklo";

function doPost(e) {
    const lock = LockService.getScriptLock();
    lock.tryLock(10000);

    try {
        // 0. Validação do Honeypot (Campo invisível preenchido = Bot)
        const honeypotField = e.parameter['website_url'];
        if (honeypotField && honeypotField.length > 0) {
            // Retorna sucesso falso imediatamente para enganar o bot e evitar processar spam.
            return ContentService.createTextOutput(JSON.stringify({ "result": "success", "message": "Mensagem recebida com sucesso." })).setMimeType(ContentService.MimeType.JSON);
        }

        // 1. Validação do reCAPTCHA
        const recaptchaToken = e.parameter['g-recaptcha-response'];
        if (!recaptchaToken) {
            return ContentService.createTextOutput(JSON.stringify({ "result": "error", "error": "ReCAPTCHA ausente (Ação bloqueada)" })).setMimeType(ContentService.MimeType.JSON);
        }

        // Conecta com a API do Google para validar se o Token é de um humano
        const verifyUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + RECAPTCHA_SECRET + "&response=" + recaptchaToken;
        const verifyResponse = UrlFetchApp.fetch(verifyUrl, { muteHttpExceptions: true });
        const verifyJson = JSON.parse(verifyResponse.getContentText());

        if (!verifyJson.success) {
            return ContentService.createTextOutput(JSON.stringify({ "result": "error", "error": "ReCAPTCHA invalido ou expirado." })).setMimeType(ContentService.MimeType.JSON);
        }

        // 2. Passou no teste do robô! Pega a planilha
        const doc = SpreadsheetApp.getActiveSpreadsheet();
        const sheet = doc.getSheetByName('Página1'); // Confirme se o nome da aba é este
        const headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
        const nextRow = sheet.getLastRow() + 1;

        // Função de Segurança: Previne CSV Injection (bots tentando executar fórmulas maliciosas na planilha)
        function limparFormula(texto) {
            if (!texto) return '';
            texto = texto.toString();
            // Se começar com caracteres que acionam fórmulas no Excel/Sheets, adicionamos um ' para forçar visualização como texto.
            if (texto.startsWith('=') || texto.startsWith('+') || texto.startsWith('-') || texto.startsWith('@')) {
                return "'" + texto;
            }
            return texto;
        }

        // 3. Cadastra a nova linha com a segurança aplicada
        const newRow = headers.map(function (header) {
            if (header === 'Data') return new Date();
            // Mapeia os campos do formulário HTML para as colunas
            if (header === 'Nome') return limparFormula(e.parameter.name);
            if (header === 'Email') return limparFormula(e.parameter.email);
            if (header === 'Telefone') return limparFormula(e.parameter.phone);
            if (header === 'Mensagem') return limparFormula(e.parameter.message);

            return '';
        });

        sheet.getRange(nextRow, 1, 1, newRow.length).setValues([newRow]);

        // 4. Enviar Email de Notificação
        MailApp.sendEmail({
            to: EMAIL_PARA_NOTIFICACAO,
            subject: ASSUNTO_EMAIL,
            htmlBody: `
        <h2>Novo Contato Recebido</h2>
        <p><strong>Nome:</strong> ${limparFormula(e.parameter.name)}</p>
        <p><strong>Email:</strong> ${limparFormula(e.parameter.email)}</p>
        <p><strong>Telefone:</strong> ${limparFormula(e.parameter.phone)}</p>
        <p><strong>Mensagem:</strong><br>${limparFormula(e.parameter.message)}</p>
        <br>
        <p><em>Dados salvos na planilha e validados pelo reCAPTCHA.</em></p>
      `
        });

        return ContentService
            .createTextOutput(JSON.stringify({ "result": "success", "row": nextRow }))
            .setMimeType(ContentService.MimeType.JSON);

    } catch (err) {
        return ContentService
            .createTextOutput(JSON.stringify({ "result": "error", "error": err.toString() }))
            .setMimeType(ContentService.MimeType.JSON);
    } finally {
        lock.releaseLock();
    }
}
